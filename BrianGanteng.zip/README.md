Kurakuraku 

Initial Project for Programming Assignment of DDP2 @ Fasilkom UI

Follow the instruction in scele.cs.ui.ac.id 
